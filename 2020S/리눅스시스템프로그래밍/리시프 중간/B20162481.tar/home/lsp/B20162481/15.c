#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <sys/stat.h>
#include <string.h>
#define TIME_STRLEN 26

struct stat statbuf;

void ssu_accmodtime(char *fname);

int main(int argc, char *argv[])
{
	time_t mod_time;
	time_t acc_time;
	//char buf[1024];

	//memset(buf, 0, sizeof(buf));
	if(argc != 2) {
		fprintf(stderr, "Usage : %s <file>\n", argv[0]);
		exit(1);
	}

	if(stat(argv[1], &statbuf) < 0) {
		fprintf(stderr, "stat() error for %s\n", argv[0]);
		exit(1);
	}

	ssu_accmodtime(argv[1]);

	exit(0);
}

void ssu_accmodtime(char *fname) {
	char buf[1024];
	int i;
	memset(buf, 0, sizeof(buf));
	strncpy(buf, fname, strlen(fname));
	strcat(buf, " accessed : ");
	strncat(buf, ctime(&statbuf.st_atime), TIME_STRLEN);
	strcat(buf, " modified : ");
	strncat(buf, ctime(&statbuf.st_mtime), TIME_STRLEN);
	
	for(i = 0; i < strlen(buf); i++)
		if(buf[i] == '\n')
			buf[i] = ' ';

	printf("%s\n", buf);
}

