#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <string.h>

#define BUFFER_SIZE 1024

int main(int argc, char *argv[]) {
	
	int fd1, fd2;
	int length;
	char buf[BUFFER_SIZE];

	if(argc != 3) {
		fprintf(stderr, "Usage : %s <file1> <file2>\n", argv[0]);
		exit(1);
	}
	
	if((fd1 = open(argv[1], O_RDONLY)) < 0) {
		fprintf(stderr, "open error for %s\n", argv[1]);
		exit(1);
	}

	if((fd2 = open(argv[2], O_RDWR | O_CREAT, 0644)) < 0) {
		fprintf(stderr, "open error for %s\n", argv[2]);
		exit(1);
	}

	while((length = read(fd1, buf, BUFFER_SIZE)) > 0) {
		write(fd2, buf, length);
		memset(buf, 0, sizeof(buf));
	}
	close(fd1);
	close(fd2);

	exit(0);
}

