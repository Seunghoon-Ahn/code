#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>
#include <string.h>

int sum_size(char *filename);

int main(int argc, char *argv[]) {
	char filename[1024];
	struct stat statbuf;
	int sum;

	strcpy(filename, argv[1]);
	
	sum = sum_size(filename);

	exit(0);
}

int sum_size(char *filename) {
	int sum= 0;
	struct stat statbuf;
	struct dirent *dentry;
	DIR *dirp;
	char temp[1024];
	int i, count;

	if(access(filename, F_OK) < 0) {
		fprintf(stderr, "error!\n");
		exit(1);
	}

	if(lstat(filename, &statbuf) < 0) {
		fprintf(stderr, "lstat error\n");
		exit(1);
	}

	if(S_ISDIR(statbuf.st_mode)) {
		dirp = opendir(filename);
		dentry = readdir(dirp);
		
		for(i = 0; i < count; i++) {
			lstat(dentry[i].d_name, &statbuf);
			if(S_ISDIR(statbuf.st_mode))
				sum += sum_size(dentry[i].d_name);
			else
				sum += statbuf.st_size;
		}
	}
	else {
		sum += statbuf.st_size;
	}

	printf("filename :%s size : %d\n", filename, sum);

	return sum;
}


