#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>

#define BUFFER_SIZE 1024

int main(void)
{
	char buf[BUFFER_SIZE];
	char *fname = "ssu_test.txt";
	int fd;

	if((fd = open(fname, O_RDONLY)) < 0) {
		fprintf(stderr, "open error for %s\n", fname);
		exit(1);
	}

	if(dup2(fd, 0) != 0) {
		fprintf(stderr, "dup2 error\n");
		exit(1);
	}

	while(scanf("%s", buf) > 0) {
		printf("fd scanf : %s\n", buf);
		memset(buf, 0, sizeof(buf));
	}

	exit(0);
}
