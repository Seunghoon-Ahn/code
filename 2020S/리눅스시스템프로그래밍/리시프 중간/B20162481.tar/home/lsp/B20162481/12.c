#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

int main(void)
{
	int fd;
	char *fname = "ssu_test.txt";
	char ch;
	int count = 0;

	if((fd = open(fname, O_RDONLY)) < 0) {
		fprintf(stderr, "open error for %s\n", fname);
		exit(1);
	}

	while(read(fd, &ch, sizeof(char)) > 0) {
		if(ch == 'm' || ch == 'M')
			count++;
	}
	
	close(fd);

	printf("m + M = %d\n", count);

	exit(0);
}

