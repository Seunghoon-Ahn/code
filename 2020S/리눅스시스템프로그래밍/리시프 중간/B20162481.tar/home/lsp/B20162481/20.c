#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define BUFLEN 512
#define QNUM 5
void print_wrong_answer(char *filename);

int main(int argc, char *argv[])
{
	if(argc < 2) {
		fprintf(stderr, "usage : %s <file> \n", argv[0]);
		exit(1);
	}
	print_wrong_answer(argv[1]);

}

void print_wrong_answer(char *filename)
{
	FILE *fp;
	char question_name[QNUM][15];
	char line[BUFLEN];
	char *ptr;
	int question_num = 0;
	int error_cnt;
	int i;

	if((fp = fopen(filename, "r")) == NULL) {
		fprintf(stderr, "fopen error for %s\n", filename);
		exit(1);
	}

	fscanf(fp, "%s\n", line);
	ptr = strtok(line, ",");
	strcpy(question_name[question_num++], ptr);
	while((ptr = strtok(NULL, ",")) != NULL) {
		strcpy(question_name[question_num++], ptr);
	}
	
	while(fscanf(fp, "%s\n", line) > 0) {
		error_cnt = 0;
		ptr = strtok(line, ",");
		printf("%s's wrong answer : ", ptr);
		for(i = 0; i < QNUM; i++) {
			ptr = strtok(NULL, ",");
			if(!strcmp("0", ptr)) {
				printf("%s ", question_name[i]);
				error_cnt++;
			}
		}
		if(error_cnt == 0)
			printf("perfect!!\n");
		else {
			printf("\n");
			printf("The number of wrong answer : %d\n", error_cnt);
		}
	}
}

