#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>

void ssu_checkfile(char *fname, time_t *time);



int main(int argc, char *argv[]) {
	struct stat statbuf;
	time_t curtime;

	if(argc != 2) {
		fprintf(stderr, "Usage : %s <file>\n", argv[0]);
		exit(1);
	}

	if(lstat(argv[1], &statbuf) < 0) {
		fprintf(stderr, "lstat error\n");
		exit(1);
	}
	
	curtime = statbuf.st_mtime;
	
	while(1) {
		ssu_checkfile(argv[1], &curtime);
		sleep(2);
	}

	exit(0);
}

void ssu_checkfile(char *fname, time_t *time) {
	struct stat statbuf;

	if(access(fname, F_OK) < 0) {
		printf("Warning : ssu_checkfile() error!\n");
		exit(1);
	}
	
	if(lstat(fname, &statbuf) < 0) {
		fprintf(stderr, "lstat error\n");
		exit(1);
	}

	if(*time != statbuf.st_mtime) {
		*time = statbuf.st_mtime;
		printf("Warning : %s was modified!.\n", fname);
	}
}


