#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>

#define SECS_IN_DAY (24 * 60 * 60)

static void displayClock(clockid_t clock, char *name);

int main(int argc, char *argv[])
{
	displayClock(CLOCK_REALTIME, "CLOCK_REALTIME");
	exit(0);
}
static void displayClock(clockid_t clock, char *name)
{
	struct timespec ts;
	long day, h, m, s;
	clock_gettime(clock, &ts);
	day = ts.tv_sec / SECS_IN_DAY;
	h = (ts.tv_sec % SECS_IN_DAY) /3600;
	m = ((ts.tv_sec % SECS_IN_DAY) % 3600) / 60;
	s = ((ts.tv_sec % SECS_IN_DAY) % 3600) % 60;
	printf("%-15s: %10ld.%03ld (", name, (long) ts.tv_sec, ts.tv_nsec / 1000000);
	printf("%ld days + %ldh %ldm %lds", day, h, m, s);
	printf(")\n");
}
