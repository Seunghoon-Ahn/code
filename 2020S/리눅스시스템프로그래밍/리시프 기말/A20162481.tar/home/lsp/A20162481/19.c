#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <sys/wait.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>

void ssu_signal_handler(int signo);

int main(void) {
	struct sigaction sig_act;
	sigset_t blk_set;
	pid_t pid;


}

void ssu_signal_handler(int signo) {
	printf("in ssu_signal_handler() function\n");
}
