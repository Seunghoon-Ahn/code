#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <syslog.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>

int ssu_daemon_init(void);

int main(void) {
/*
	if(ssu_daemon_init() < 0) {
		fprintf(stderr, "daemon error\n");
		exit(1);
	}
	exit(0);
}

int ssu_daemon_init(void) {
*/
	pid_t pid;
	int fd, maxfd;

	if((pid = fork()) < 0) {
		fprintf(stderr, "fork error\n");
		exit(1);
	}
	else if(pid != 0)
		exit(0);

	pid = getpid();

	setsid();
	signal(SIGTTIN, SIG_IGN);
	signal(SIGTTOU, SIG_IGN);
	signal(SIGTSTP, SIG_IGN);
	maxfd = getdtablesize();
	for(fd = 0; fd < maxfd; fd++)
		close(fd);

	umask(0);
	chdir("/");
	fd = open("/dev/null", O_RDWR);
	dup(0);
	dup(0);

	fd = open("/var/log/system.log", O_RDWR | O_CREAT, 0644);
	
	char buf[1024];
	time_t curtime = time(NULL);
	sprintf(buf, "%s", ctime(&curtime));
	buf[strlen(buf) - 1] = '\0';
	strcat(buf, " oslab a.out : My pid is ");
	sprintf(buf+strlen(buf), "%d\n", pid);
	write(fd, buf, strlen(buf));

	return 0;
}

