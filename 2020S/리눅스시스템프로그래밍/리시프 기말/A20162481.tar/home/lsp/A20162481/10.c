#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

char buf[500000];

int main()
{
	int ntowrite, nwrite;
	char *ptr;
	ptr = buf;
	int fd, errno;

	while((nwrite = read(STDIN_FILENO, buf, sizeof(buf))) != 0) {
		fprintf(stderr, "reading %d bytes\n", ntowrite);
	
		write(STDOUT_FILENO, buf, sizeof(buf));
		while (ntowrite > 0) {
			errno = 0;
			if(nwrite > 0) {
				ptr += nwrite;
				ntowrite-= nwrite;
			}
		}
	}
	exit(0);
}
void set_flags(int fd, int flags) {

	int val;
}

void clr_flags(int fd, int flags) {
	int val;
}
