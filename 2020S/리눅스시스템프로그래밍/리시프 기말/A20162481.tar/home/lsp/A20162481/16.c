#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <string.h>
#include <fcntl.h>
#define BUFFER_SIZE 1024

int main(int argc, char* argv[])
{
	char buf[BUFFER_SIZE];
	time_t now;
	char *filename = "ssu_log";
	int ret;
	FILE *fp;
	
	memset(buf, 0, BUFFER_SIZE);

	close(STDERR_FILENO);
	dup(6);
	dup(6);
	ret = system(argv[1]);
	fp = fopen(filename, "a+");
	if(ret == 0) {
		now = time(NULL);
		sprintf(buf, "[%s", ctime(&now));
		buf[strlen(buf)-1] = ']';
		strcat(buf, " ");
		strcat(buf, argv[1]);
		strcat(buf, "\n");
		fputs(buf, fp);
	}
	exit(0);
}

