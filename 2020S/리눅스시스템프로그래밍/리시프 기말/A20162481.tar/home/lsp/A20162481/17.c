#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>

int main(void)
{
	sigset_t pending_sigset;
	sigset_t set;


	sigemptyset(&set);
	sigaddset(&set, SIGQUIT);
	sigaddset(&set, SIGINT);
	sigaddset(&set, SIGTSTP);
	sigprocmask(SIG_BLOCK, &set, NULL);

	printf("KIll SIGQUIT, SIGINT, and SIGTSTP signals to this process.\n");

	sleep(3);

	sigpending(&pending_sigset);

	printf("\nBlocked Signals\n");
	if(sigismember(&pending_sigset, SIGINT))
		printf("SIGINT\n");
	if(sigismember(&pending_sigset, SIGTSTP))
		printf("SIGTSTP\n");
	if(sigismember(&pending_sigset, SIGQUIT))
		printf("SIGQUIT\n");

	if(!(sigismember(&set, SIGQUIT) || sigismember(&set, SIGINT) || sigismember(&set, SIGTSTP)))
		printf("If you kill SIGQUIT or SIGINT or SIGTSTP Signals, this message will not be shown\n");

	exit(0);
}

