#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(void)
{
	while(1) {
		printf("\n[OSLAB]");
		sleep(5);
	}//출력 후 5초 멈춤 무한 반복

	exit(0);
}

