#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	printf("Good afternoon");
	exit(0); //입출력 버퍼를 정리하고 프로그램을 종료함
} //printf가 출력됨
