#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>

int main(int argc, char *argv[])
{
    struct stat statbuf; 
    ino_t inode;

    if(argc != 3){
        fprintf(stderr, "argc != 3\n");
        exit(1);
    }

    if((stat(argv[1], &statbuf)) < 0){
        fprintf(stderr, "stat error\n");
        exit(1);
    }

    printf("%s's inode = %lu -> ", argv[1], statbuf.st_ino);

    if(link(argv[1], argv[2]) == -1){
        fprintf(stderr, "link() error\n");
        exit(1);
    }

    if(unlink(argv[1]) < 0){
        fprintf(stderr, "ulink() error\n");
        exit(1);
    }

    if((stat(argv[2], &statbuf)) < 0){
        fprintf(stderr, "stat error\n");
        exit(1);
    }

    printf("%s's inode = %lu\n", argv[2], statbuf.st_ino);

    exit(0);
}