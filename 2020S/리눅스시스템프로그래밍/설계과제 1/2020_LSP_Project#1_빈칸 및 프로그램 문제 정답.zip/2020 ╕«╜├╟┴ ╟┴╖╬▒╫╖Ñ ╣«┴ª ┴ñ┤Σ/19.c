#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>

#define BUFLEN 512

void make_files(char *filename);

int main(int argc, char *argv[])
{
    char buf[BUFLEN];

    if(argc < 2){
        fprintf(stderr, "usage : %s <file1>\n", argv[0]);
        exit(1);
    }

    if(access(argv[1], F_OK) < 0){
        fprintf(stderr, "%s doesn't exist.\n", argv[1]);
        exit(1);
    }

    make_files(argv[1]);
}

void make_files(char *filename)
{
    int fd;
    char name[15];
    char buf[BUFLEN];

    memset(name, 0, sizeof(buf));
    strncpy(name, filename, strlen(filename) - strlen(strrchr(filename, '.')));

    sprintf(buf, "gcc -o %s.stdexe %s.c", name, name);
    system(buf);

    sprintf(buf, "%s.stdout", name);
    if((fd = creat(buf, 0666)) < 0){
        fprintf(stderr, "creat error for %s\n", buf);
        return;
    }

    sprintf(buf, "./%s.stdexe", name);
    dup2(fd, 1);
    system(buf);

    close(fd);
}