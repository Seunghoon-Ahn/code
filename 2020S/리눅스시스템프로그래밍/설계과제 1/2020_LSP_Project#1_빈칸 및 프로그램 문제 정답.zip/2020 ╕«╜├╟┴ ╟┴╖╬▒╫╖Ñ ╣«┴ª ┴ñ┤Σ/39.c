#include <stdio.h>
#include <stdlib.h>

#define BUFSIZE 256

int main(int argc, char * argv[])
{
	FILE * fp;
	int length = 0, cnt = 0; // length : 파일 크기, cnt : 라인 넘버
	char strJava[BUFSIZE];
	
	if((fp = fopen(argv[1], "r")) == NULL){
		fprintf(stderr, "fopen error\n");
		exit(1);
	}
	
	fseek(fp, 0, SEEK_END);
	length = ftell(fp);
	
	printf("%s file size if %d bytes\n", argv[1], length);
	
	fseek(fp, 0, SEEK_SET);
	
	while(!feof(fp)){
		
		if(fread(strJava, 1, 1, fp) == 0)
			break;
		else
			fseek(fp, -1, SEEK_CUR);
		
		fgets(strJava, sizeof(strJava), fp);
		cnt++;
	}
	
	fclose(fp);
	printf("%s line number is %d lines\n", argv[1], cnt);
	return 0;
}