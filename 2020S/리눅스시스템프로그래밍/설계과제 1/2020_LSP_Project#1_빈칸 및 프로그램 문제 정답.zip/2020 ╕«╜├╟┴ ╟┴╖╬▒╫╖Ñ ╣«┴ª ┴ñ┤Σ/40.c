#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include <dirent.h>
#include <time.h>
#include <sys/stat.h>
#include<fcntl.h>

void file_backup(char *);
char **getTimeBackupList(char *, int *,int);
char *strTodate(char *);

void main(int argc, char **argv)
{
	if(argc <2)
	{
		perror("fewer parameters\n");
		exit(1);
	}	
	else if(2<argc)
	{
		perror("usage :backup\n");
		exit(1);
	}
	if(access(argv[1],F_OK)<0)
	{
		perror("<FILENAME> not Exist\n");
		exit(1);
	}
	while(1)
	{
		file_backup(argv[1]);
		sleep(3);
		system("ls ");
	}
}

char *strTodate(char *old_str){
	char date[14] = {0};
	time_t timer;
	struct tm *t;
	
	timer = time(NULL);
	t = localtime(&timer);
	
	char *result = (char *)calloc(sizeof(char), PATH_MAX);
	
	strcpy(result,old_str);
	sprintf(date, "_%02d%02d%02d%02d%02d%02d",t->tm_year %100, t->tm_mon + 1, t->tm_mday, t->m_hour, t->tm_min, t->tm_sec);
	strcat(result, date);
	return result;
}

char **getTimeBackupList(char *name, int *ret,int timer){
	char *real = strTodate(name);
	int length = strlen(real);
	struct dirent **namelist;
	char buf[255];
	int cnt = scandir(".", &namelist, NULL, alphasort);
	char **list = (char **)malloc(cnt * sizeof(char *));
	int many = 0;
	char ptr[255];
	char *pptr;
	int len=0;
	struct tm strparsing={0},strnowparsing={0}, *t;
	time_t now;
	long long int nowtime,filetime;
	now =time(NULL);
	t=localtime(&now);
	char nowtimestamp[255];
	sprintf(nowtimestamp, "%02d%02d%02d%02d%02d%02d",t->tm_year %100, t->tm_mon + 1, t->tm_mday, t->tm_hour, t->tm_min, t->tm_sec);

	for (int i = 0; i <cnt; i++)
	{
		if ((!strcmp(namelist[i]->d_name, ".") || !strcmp(namelist[i]->d_name, "..")))
			continue;
		if(strlen(namelist[i]->d_name)!= length)
			continue;
		
		int namelen =strlen(namelist[i]->d_name);
		for(int j = 0 ; j< namelen;j++)
		{
			if(namelist[i]->d_name[j] =='_')
			{
				if (!strncmp(namelist[i]->d_name,name,j))
				{
					int timercnt=0;
					char timestamp[255];
					char datelist[6][3];
					char nowlist[6][3];

					strcpy(timestamp,(namelist[i]->d_name)+j+1);
					timercnt=strlen(timestamp);

					int iter =0,datelevel=0;
					int nowyear=0, fileyear=0;

					while(datelevel<6)
					{
						datelist[datelevel][0]=timestamp[iter];nowlist[datelevel][0]=nowtimestamp[iter++];
						datelist[datelevel][1]=timestamp[iter];nowlist[datelevel][1]=nowtimestamp[iter++];
						datelist[datelevel][2]='\0';nowlist[datelevel][2]='\0';
						datelevel++;
					}

					nowyear =atoi(nowlist[0]);
					fileyear=atoi(datelist[0]);
					strparsing.tm_mon=atoi(datelist[1]);strparsing.tm_mday=atoi(datelist[2]);
					strparsing.tm_hour=atoi(datelist[3]);strparsing.tm_min=atoi(datelist[4]);
					strparsing.tm_sec=atoi(datelist[5]);strnowparsing.tm_mon=atoi(nowlist[1]);
					strnowparsing.tm_mday=atoi(nowlist[2]);strnowparsing.tm_hour=atoi(nowlist[3]);
					strnowparsing.tm_min=atoi(nowlist[4]); strnowparsing.tm_sec=atoi(nowlist[5]);
					nowtime=0; filetime=0;
					nowtime +=(2592000*12) * nowyear; nowtime +=2592000 *strnowparsing.tm_mon;
					nowtime +=86400 *strnowparsing.tm_mday;nowtime +=3600 *strnowparsing.tm_hour;
					nowtime +=60 *strnowparsing.tm_min;nowtime +=strnowparsing.tm_sec;
					filetime +=(2592000 *12) *fileyear;filetime +=2592000 *strparsing.tm_mon;
					filetime +=86400 *strparsing.tm_mday; filetime +=3600 *strparsing.tm_hour;
					filetime +=60 *strparsing.tm_min;filetime +=strparsing.tm_sec+timer;

					if(nowtime>filetime)
					{
						list[many] = (char *)malloc(sizeof(char) * strlen(namelist[i]->d_name));
						strcpy(list[many],(namelist[i]->d_name));
						many++;
						break;
					}
				}
			}
		}
	}
	
	for (int i = 0; i <cnt; i++)
		free(namelist[i]);
	
	free(namelist);
	*ret = many;
	return list;
}

void file_backup(char *filename)
{
	char *data;
	char *backuptime;
	struct stat src_st;
	int tcnt=0,fd =0,nfd=0,len=0;
	int i=0;
	char **gettime =getTimeBackupList(filename,&tcnt,10);

	for(int i = 0 ; i< tcnt ; i++)
	{
		char buf[255];
		unlink(gettime[i]);
	}
	
	if((fd=open(filename,O_RDONLY))<0)
	{
		fprintf(stderr,"%s is not exit \n",filename);
		return;
	}

	stat(filename,&src_st);
	backuptime=strTodate(filename);
	nfd =open(backuptime,O_CREAT | O_TRUNC | O_WRONLY ,666);

	if(nfd <0)
	{
		printf("strtohex error %s \n",backuptime);
		return;
	}

	data =(char*)malloc(src_st.st_size);

	while((len=read(fd,data,src_st.st_size))>0)
	{
		write(nfd,data,len);
	}

	free(data);
	close(fd);
}