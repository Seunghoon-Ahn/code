#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <string.h>

int main(int argc, char *argv[]){
    mode_t mode=0;
    int digit;
    int flag_b=0;
    int i, j;
    char mode_arg[30] = {0, };

    if(argc < 3){
        fprintf(stderr, "usage : ssu_chmod MODE FILE...\n");
        exit(1);
    }

    strcpy(mode_arg, argv[1]);

    while((i = getopt(argc, argv, "b:")) > 0){
        switch(i){
            case 'b':
                flag_b = 1;
                strcpy(mode_arg, optarg);
                break;
            default:
                fprintf(stderr, "unknown option\n");
                exit(1);
        }
    }

    for(i = strlen(mode_arg)-1, j=0; i >= 0; i--, j++){
        digit = mode_arg[i] - '0';

        if(flag_b){
            if(digit < 0 || digit > 1){
                fprintf(stderr, "MODE error : %s\n", mode_arg);
                exit(1);
            }

            mode = mode | (digit << j);
        }
        else{
            if(digit < 0 || digit > 7){
                fprintf(stderr, "MODE error : %s\n", mode_arg);
                exit(1);
            }

            mode = mode | (digit << j*3);
        }
    }

    for(i = flag_b==0?2:3; i < argc; i++)
        if(chmod(argv[i], mode) < 0)
            fprintf(stderr, "chmod() error\n");

    return 0;
}