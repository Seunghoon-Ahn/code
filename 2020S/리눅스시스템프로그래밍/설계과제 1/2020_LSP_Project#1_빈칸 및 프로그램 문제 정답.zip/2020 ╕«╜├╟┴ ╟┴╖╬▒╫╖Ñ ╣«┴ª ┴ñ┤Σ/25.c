#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <ctype.h>

#define pid_max 20

int main(int argc, char *argv[])
{	
    int pid[pid_max];
    int pid_count = 0;
    int sig_pst = 0; 	//signal position in argv[]   
    int n = 0;

    if (argc <1) {
        fprintf(stderr, "usage: %s <-signal> <pid> ...\n", argv[0]);        
        exit(1);
    }
	
    for(int i=1; i<argc;i++){
         if(strstr(argv[i],"-")!=NULL){
            if(sig_pst!=0){    //check <-signal> use times
                fprintf(stderr,"<-signal> only can use 1 time\n");
                exit(1);
            }
            sig_pst = i;
         }
    }

    if(strstr(argv[1],"-")!=NULL){
        pid_count = argc-2;
		
        for(int i=0;i<pid_count;i++){
            if(sig_pst == i+1 &&sig_pst!=1)			
                continue;
			
            pid[n] = atoi(argv[2+i]);
            printf("pid %d\n",pid[n]);
			
            if(sig_pst != 1){  //EX: ./ssu_kill pid -signal
                printf("SIGTERM\n");
                kill(pid[n],SIGTERM);
            }
            else if(strcasecmp(argv[1],"-SIGINT")==0)
                kill(pid[n],SIGINT);
            else if(strcasecmp(argv[1],"-SIGUSR1")==0)
                kill(pid[n],SIGUSR1);
            else if(strcasecmp(argv[1],"-SIGKILL")==0)
                kill(pid[n],SIGKILL);
            else if(isdigit(argv[1][1])) //-signal is consisted by number [-9,-10]
                kill(pid[n],atoi(argv[1]+1));

            n++;
        }	
    }
    else{
        pid_count = argc-1;
        printf("sig_pst: %d\n",sig_pst); 
        for(int i=0;i<pid_count;i++){
            if(sig_pst == i+1)
                continue;
	
            pid[n] = atoi(argv[1+i]);
            kill(pid[n],SIGTERM);
            n++;
        }
    }

    exit(0);
}