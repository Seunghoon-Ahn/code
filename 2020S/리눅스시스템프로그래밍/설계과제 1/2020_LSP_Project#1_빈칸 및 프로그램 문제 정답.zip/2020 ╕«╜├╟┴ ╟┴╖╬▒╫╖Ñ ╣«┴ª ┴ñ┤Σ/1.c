#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void print_file_type(struct stat *statbuf) {
    char *str;

    if (S_ISREG(statbuf -> st_mode)) // (statbuf->st_mode & S_IFMT) == S_IFREG 가능
            str = "regular";
        else if (S_ISDIR(statbuf -> st_mode)) // (statbuf->st_mode & S_IFMT) == S_IFDIR 가능
            str = "directory";
	else if (S_ISCHR(statbuf -> st_mode)) // (statbuf->st_mode & S_IFMT) == S_IFCHR 가능
            str = "character special";
        else if (S_ISBLK(statbuf -> st_mode)) // (statbuf->st_mode & S_IFMT) == S_IFBLK 가능
            str = "block special";
        else if (S_ISFIFO(statbuf -> st_mode)) // (statbuf->st_mode & S_IFMT) == S_IFIFO 가능
            str = "FIFO";
        else if (S_ISLNK(statbuf -> st_mode)) // (statbuf->st_mode & S_IFMT) == S_IFBLK 가능
            str = "symbolic link";
        else if (S_ISSOCK(statbuf -> st_mode)) // (statbuf->st_mode & S_IFMT) == S_IFSOCK 가능
            str = "socket";
        else
            str = "unknown mode";

        printf("%s\n", str);
}

int main(int argc, char *argv[])
{
    struct stat statbuf;
    int i;
    FILE *fp

    if((fp=fopen(argv[0], "r")) < 0){
        fprintf(stderr, "fopen error for %s\n", argv[0]);
        exit(1);
    }
    fgets(NULL, 0, fp);
    fclose(fp);

    if((fp=fopen(argv[0], "r")) < 0){
        fprintf(stderr, "fopen error for %s\n", argv[0]);
        exit(1);
    }
    fgets(NULL, 0, fp);
    fclose(fp);

    for(i = 1; i < argc; i++){
        if (lstat(argv[i], &statbuf) < 0  ) {
             fprintf(stderr, "error\n");
            exit(1);
        }
        print_file_type(&statbuf);
    }

    exit(0);
}