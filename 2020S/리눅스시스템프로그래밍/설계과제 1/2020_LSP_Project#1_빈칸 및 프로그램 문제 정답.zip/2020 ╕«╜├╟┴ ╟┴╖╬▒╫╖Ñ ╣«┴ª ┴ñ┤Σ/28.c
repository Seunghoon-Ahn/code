#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>

#define BUFFER_SIZE 1024
#define ERROR_MSG "ssu_cp error\nusage : cp [-d][N] (1 <= N < 10)\n"
#define isdigit(x) (x>='0'&&x<='9')?1:0 //숫자 판단 매크로

void check_flag(int argc, char *argv[]);
static int filter(const struct dirent *dirent);
void copy_dir(char *source, char *target);

int flag_d ,N;

int main(int argc, char *argv[])
{
	char opt;
	struct timeval start, end;
	char source[PATH_MAX+1];
	char target[PATH_MAX+1];
	struct stat source_info, target_info;
	while((opt = getopt(argc, argv, "d:")) != -1) //옵션 인자처리
	{
		switch(opt)
		{
			case 'd':
				for( int i = 0; i < strlen(optarg); i++)
				{
					if(!isdigit(optarg[i])) 
					{
						fprintf(stderr, "put the depth N number.\n");
						exit(1);
					}
				N = optarg[i] - '0';
				}
				flag_d = 1;
				break;
			
			case '?' :
				break;
		}
	}
	strcpy(source, argv[argc-2]);
	strcpy(target, argv[argc-1]);

	printf("target : %s\n", target);
	printf("source : %s", source);
	
	if (access(source, F_OK) < 0) {
		fprintf(stderr, "\nssu_cp: %s: No such file or directory\n", source);
		printf(ERROR_MSG);
		exit(1);
	}
	if (lstat(source, &source_info) < 0) {		
		fprintf(stderr, "\nlstat error for %s\n", source);
		exit(1);
	}
	if (flag_d) {
		if (!(1<=N && N<10)) {
			fprintf(stderr, "not invalid N size\n");
			printf(ERROR_MSG);
			exit(1);
		}
	}
	umask((mode_t)0000); 
if ( flag_d) {
		int length = strlen(source);
		if (source[length - 1] == '/') {
			if (length != 1)
				source[length - 1] = '\0';
		}
		length = strlen(target);
		if (target[length - 1] == '/') {
			if (length != 1)
				target[length - 1] = '\0';
		}
		copy_dir(source, target);	
	}
	exit(0);
}

void copy_dir(char *source, char *target) {
	struct stat source_info;
	struct stat target_info;
	struct dirent **namelist;
	char source_name[PATH_MAX];
	pid_t check_pid;
	int status;
	int source_length;
	int target_length;
	int count;
	int i;
	
	if (stat(source, &source_info) < 0) {
		fprintf(stderr, "stat error for %s\n", source);
		return;
	}
	printf( "src : %s , dst : %s \n",source, target);
	source_length = strlen(source);
	target_length = strlen(target);
	if (access(target, F_OK) == 0) {
		if (lstat(target, &target_info) < 0) {
			fprintf(stderr, "lstat error for %s\n", target);
			return;
		}
		if (!S_ISDIR(target_info.st_mode)) { //일반파일 일 때
			fprintf(stderr, "ssu_cp: cannot overwrite non-directory '%s' with directory '%s'\n", target, source);
			return;
		}
		else { 
			char *temp_source = (char *)malloc(sizeof(char) * (strlen(source) + 1));
			strcpy(temp_source, source);
			char *token = strtok(temp_source, "/");
			while(token != NULL) {
				strcpy(source_name, token);
				token = strtok(NULL, "/");
			}
			if ((count = scandir(target, &namelist, filter, alphasort)) == -1) {
				fprintf(stderr, "%s Directory Scan Error : %s\n", target, strerror(errno));
				return;
			}
			for (i = 0; i < count; i++) { //target directory안에 source directory이름과 같은 file or directory가 있는지 확인
				if (strcmp(source_name, namelist[i]->d_name) == 0) {
					strcat(target, "/");
					strcat(target, source_name);
					if (lstat(target, &target_info) < 0) {
						fprintf(stderr, "lstat error for %s\n", target);
						return;
					}
					if (!S_ISDIR(target_info.st_mode)) {
						fprintf(stderr, "ssu_cp: cannot overwrite non-directory '%s' with directory '%s'\n", target, source);
						return;
					}
					else {
						target_length = strlen(target);
						goto copy;
					}
				}
			}
			for (i = 0; i < count; i++)
				free(namelist[i]);
			free(namelist);
			strcat(target, "/");
			strcat(target, source_name);		
			copy_dir(source, target);
			free (temp_source);
		}
	}
	else { 
		if (mkdir(target, source_info.st_mode) < 0) {
			fprintf(stderr, "mkdir error for %s\n", target);
			return;
		}	
copy:
		if ((count = scandir(source, &namelist, filter, alphasort)) == -1) {
			fprintf(stderr, "%s Directory Scan Error : %s\n", source, strerror(errno));
			return;
		}
		for (i = 0; i < count; i++) {
			strcat(source, "/");
			strcat(source, namelist[i]->d_name);
			if (stat(source, &source_info) < 0) {
				fprintf(stderr, "stat error for %s, pid : %d\n", source, getpid());
				return;
			}
			strcat(target, "/");
			strcat(target, namelist[i]->d_name);
			if (!S_ISDIR(source_info.st_mode)) {
				target[target_length] = '\0';
			}
			else {
				if (flag_d) {
					if (1 <= N) {
						N--;
						check_pid = fork();

						if (check_pid == 0) {
							printf("Directory %s copied by Process id : %d\n", source, getpid());
						}
						if (check_pid > 0) {
							source[source_length] = '\0';
							target[target_length] = '\0';
							continue;
						}
					}
				}
				copy_dir(source, target);	
				target[target_length] = '\0';
				if (flag_d) { 
					if (check_pid == 0) 
						exit(0);
				}
			}
			source[source_length] = '\0';
		}
		for (i = 0; i < count; i++)
			free(namelist[i]);
		free(namelist);
		if (flag_d) {
			if (check_pid > 0)
				waitpid(check_pid, &status, 0);
		}
	}
}
static int filter(const struct dirent *dirent) {
	if (!(strcmp(dirent->d_name, ".")) || !(strcmp(dirent->d_name, "..")))
		return 0;
	else
		return 1;
}