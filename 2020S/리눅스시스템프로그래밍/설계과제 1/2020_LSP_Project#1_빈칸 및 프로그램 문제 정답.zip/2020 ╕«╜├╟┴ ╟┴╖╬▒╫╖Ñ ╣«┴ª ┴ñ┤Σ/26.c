#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void *ssu_thread1(void *arg);
void *ssu_thread2(void *arg);

pthread_mutex_t mutex1
pthread_mutex_t mutex2
pthread_cond_t cond1
pthread_cond_t cond2

int count = 0;
int input1 = 0, input2 = 0;
int result;
char buf[BUFSIZ];

int main(void)
{
    pthread_t tid1, tid2;
    int status;

    if(pthread_create(&tid1, NULL, ssu_thread1, NULL) != 0){
        fprintf(stderr, "pthread_create error\n");
        exit(1);
    }

    if(pthread_create(&tid2, NULL, ssu_thread2, NULL) != 0){
        fprintf(stderr, "pthread_create error\n");
        exit(1);
    }

    while(1){
        //입력, 양수P양수의 형태만 가능
        scanf("%dP%d", &input1, &input2);
		
        if((input1 > 0 && input2 > 0) && input1 >= input2){
            pthread_cond_signal(&cond1);
            break;
        }
        else{
            input1 = 0;
            input2 = 0;
            while(getchar() != '\n');
        }
    }

    pthread_join(tid1, (void *)&status);
    pthread_join(tid2, (void *)&status);

    pthread_mutex_destroy(&mutex1);
    pthread_mutex_destroy(&mutex2);
    pthread_cond_destroy(&cond1);
    pthread_cond_destroy(&cond2);

    printf("complete \n");
    exit(0);
}

void *ssu_thread1(void *arg){
    while(1){
        pthread_mutex_lock(&mutex1);

        if(input1 == 0 && input2 == 0)
            pthread_cond_wait(&cond1, &mutex1);

        if(input2 == count){
            pthread_cond_signal(&cond2);
            break;
        }

        if(count == 0){
            sprintf(buf, "%d", input1);
            result = input1;
            count++;
            printf("Thread 1 : %s=%d\n", buf, result);
        }
        else if(count % 2 == 0){
            sprintf(buf, "%s x %d", buf, input1-count);
            result *= (input1-count);
            count++;
            printf("Thread 1 : %s=%d\n", buf, result);
        }

        pthread_cond_signal(&cond2);
        pthread_cond_wait(&cond1, &mutex1);
        pthread_mutex_unlock(&mutex1);
    }

    return NULL;
}

void *ssu_thread2(void *arg){
    while(1){
        pthread_mutex_lock(&mutex2);

        if(input1 == 0 && input2 == 0)
            pthread_cond_wait(&cond2, &mutex2);

        if(input2 == count){
            pthread_cond_signal(&cond1);
            break;
        }

        if(count % 2 == 1){
            sprintf(buf, "%s x %d", buf, input1-count);
            result *= (input1-count);
            count++;
            printf("Thread 2 : %s=%d\n", buf, result);
        }

        pthread_cond_signal(&cond1);
        pthread_cond_wait(&cond2, &mutex2);
        pthread_mutex_unlock(&mutex2);
    }

    return NULL;
}