#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#define MAXLEN 256

int main(int argc, char *argv[])
{
	char * fname, * makefile;
	// fname : argv 인자를 받는 문자열, makefile : Makefile 파일명
	char * tempStr;
	// Makefile 파일 입력 시 임시로 사용되는 문자열
	int fd;
	// Makefile 파일 디스크립터
	
	makefile = malloc(sizeof(char) * MAXLEN);
	tempStr = malloc(sizeof(char) * MAXLEN);

	memset(makefile, 0, sizeof(makefile));
	memset(tempStr, 0, sizeof(tempStr));

	fname = strtok(argv[1], ".");
	
	sprintf(makefile, "%s_Makefile", fname);
	
	if((fd = open(makefile, O_RDWR|O_CREAT|O_TRUNC, 0644)) == 0){
		fprintf(stderr, "open error for %s\n", makefile);
		exit(1);
	}

	sprintf(tempStr, "%s : %s.o\n", fname, fname);
	write(fd, tempStr, strlen(tempStr));

	memset(tempStr, 0, sizeof(tempStr));
	sprintf(tempStr, "\tgcc -o %s %s.o\n", fname, fname);
	write(fd, tempStr, strlen(tempStr));

	memset(tempStr, 0, sizeof(tempStr));
	sprintf(tempStr, "%s.o : %s.c\n", fname, fname);
	write(fd, tempStr, strlen(tempStr));
	
	memset(tempStr, 0, sizeof(tempStr));
	sprintf(tempStr, "\tgcc -c -o %s.o %s.c\n", fname, fname);
	write(fd, tempStr, strlen(tempStr));
	
	memset(tempStr, 0, sizeof(tempStr));
	sprintf(tempStr, "clean : \n");
	write(fd, tempStr, strlen(tempStr));

	memset(tempStr, 0, sizeof(tempStr));
	sprintf(tempStr, "\trm %s\n", fname);
	write(fd, tempStr, strlen(tempStr));

	close(fd);
	printf("%s make success\n", makefile);
	return 0;
}