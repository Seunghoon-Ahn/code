#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<dirent.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<pthread.h>

#define MAX_DIR 64
#define	true 1
#define false 0
typedef int bool;

char pathname[PATH_MAX];
char dirname[PATH_MAX];
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

typedef struct thread_struct
{
	struct thread_struct *next;
	pthread_t tid;
	char *data;
} ssu_thread;

ssu_thread *HEAD = NULL, *TAIL = NULL;

char *dir_list[MAX_DIR];
int dir_cnt = 0;
bool isnewfile = false; 
int startfile_fin = 0;

void directory_monitor(char *link);
ssu_thread *make_thread(char *data);
void thread_function(void *arg);
void monitor_function(char *name);
void print_log(char *name, int size, time_t mt, int index);
int check_list(char *data);
void delete_list(char *name);

int main(int argc, char *argv[]){

	if (argc != 2){
		fprintf(stderr, "usage : ./<<<MW2>>> <directory>\n");
		exit(1);
	}

	realpath(argv[1], pathname);
	strcpy(dirname, argv[1]);

	if (access(argv[1], F_OK) != 0){
		fprintf(stderr, "usage : Target directory not exist\n");
		exit(1);
	}

	struct stat st;
	stat(pathname, &st);

	if(!S_ISDIR(st.st_mode)){
		fprintf(stderr, "usage : Target must be directory\n");
		exit(1);
	}

	time_t old = 0, new = 0;
	time_t dir_time_now[MAX_DIR] = {0};
	time_t dir_time_new;
	while (1){
		stat(pathname, &st);
		if (access(pathname, F_OK) != 0){
			print_log(pathname, 0, 0, 3);
			exit(0);
		}

		new = st.st_mtime; 
		if (new != old){ 
			directory_monitor(pathname);
			old = new;
		}

		for (int i = 0; i < dir_cnt; i++){
			if (access(dir_list[i], F_OK) == 0) {
				stat(dir_list[i], &st); 
				dir_time_new = st.st_mtime;
				if (dir_time_now[i] != dir_time_new) 
				{
					directory_monitor(dir_list[i]);
					dir_time_now[i] = dir_time_new;
				}
			}
		}

		if(!isnewfile){
			int startfile_cnt = 0;
			ssu_thread *cur;
			for (cur = HEAD; cur != NULL; cur = cur->next) 
			{
				startfile_cnt++;
			}
			while(startfile_cnt != startfile_fin)
				;
			isnewfile = true;
		}
	}
}

void directory_monitor(char *link)
{
	struct dirent **namelist;
	int cont_cnt = scandir(link, &namelist, NULL, alphasort);

	for (int i = 0; i < cont_cnt; i++)
	{
		if ((!strcmp(namelist[i]->d_name, ".") || !strcmp(namelist[i]->d_name, "..")))
			continue; 

		char *resource = (char *)malloc(PATH_MAX);
		struct stat src;
		sprintf(resource, "%s/%s", link, namelist[i]->d_name);
		stat(resource, &src);

		if (S_ISDIR(src.st_mode))
		{
			int k;
			for (k = 0; k < dir_cnt; k++)
			{
				if (strcmp(dir_list[k], resource) == 0) 
					break;
			}
			if (k == dir_cnt) 
			{
				dir_list[k] = resource;
				dir_cnt++;
			}
			directory_monitor(resource); 
		}
		else 
		{
			if (check_list(resource))
			{
				if (HEAD == NULL)
				{
					HEAD = make_thread(resource);
					TAIL = HEAD;
				}
				else
				{
					TAIL->next = make_thread(resource);
					TAIL = TAIL->next;
				}
			}
		}
	}

	for (int i = 0; i < cont_cnt; i++)
		free(namelist[i]); 
	free(namelist);

	return;
}

ssu_thread *make_thread(char *data){
	ssu_thread *temp = (ssu_thread *)malloc(sizeof(ssu_thread));
	temp->data = data; 
	temp->next = NULL;

	if(pthread_create(&(temp->tid), NULL, (void *)(&thread_function), (void *)data) != 0){
		fprintf(stderr, "pthread_crate error\n");
	}
	return temp;
}

void thread_function(void *arg){
	char *data = (char *)arg;
	monitor_function(data);
}

void monitor_function(char *name){ 
	struct stat src_sc;
	time_t old = 0, new = 0;
	int i = 0;
	int check = 0;

	while (true)
	{
		if (access(name, F_OK) != 0){
			print_log(name, 0, new, 3);
			delete_list(name);
			pthread_exit(0);
		}

		stat(name, &src_sc);
		new = src_sc.st_mtime;

		if (new == old){ 
			continue;
		}

		if (old == 0){
			if(!isnewfile)
				;
			else
				print_log(name, src_sc.st_size, new, 1);
		}
		else if(old != new){
			print_log(name, src_sc.st_size, new, 2);
		}

		
		old = new;
		if(!isnewfile)
			startfile_fin++;


	}
}

void print_log(char *name, int size, time_t mt, int index){
	time_t timer = time(NULL);		 
	struct tm *t = localtime(&timer);
	char temp[14];
	sprintf(temp, "%02d%02d %02d:%02d:%02d", t->tm_mon + 1, t->tm_mday, t->tm_hour, t->tm_min, t->tm_sec);
	struct tm *tt = localtime(&mt);
	int k;

	for (k = strlen(name) - 1; k >= 0; k--)
	{
		if (name[k] == '/')
			break;
	}
	k++;

	pthread_mutex_lock(&mutex);
	switch (index)
	{
	case 1:
		printf("[%s] %s is created [size:%d/mtime:%02d%02d %02d:%02d:%02d]\n", temp, name + k, size, tt->tm_mon + 1, tt->tm_mday, tt->tm_hour, tt->tm_min, tt->tm_sec);
		break;
	case 2:
		printf("[%s] %s is modified [size:%d/mtime:%02d%02d %02d:%02d:%02d]\n", temp, name + k, size, tt->tm_mon + 1, tt->tm_mday, tt->tm_hour, tt->tm_min, tt->tm_sec);
		break;
	case 3:
		printf("[%s] %s is deleted\n", temp, name + k);
		break;
	}
	pthread_mutex_unlock(&mutex);
}


int check_list(char *data)
{
	ssu_thread *cur;
	for (cur = HEAD; cur != NULL; cur = cur->next) 
	{
		if (strcmp(cur->data, data) == 0)
			return 0; 
	}
	return 1; 
}

void delete_list(char *name){
	ssu_thread *cur;
	for (cur = HEAD; cur != NULL; cur = cur->next) 
	{
		if (strcmp(cur->data, name) == 0){
			cur->data[0] = '\0';
			return;
		}
	}
	return;
}