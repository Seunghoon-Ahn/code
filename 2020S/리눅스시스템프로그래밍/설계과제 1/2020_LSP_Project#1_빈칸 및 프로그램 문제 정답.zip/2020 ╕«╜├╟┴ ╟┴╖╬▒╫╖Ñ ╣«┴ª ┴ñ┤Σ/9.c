#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>

#define MAX_TARGET 5
#define MAX_DEPENDENCY 4
#define MAX_COMMAND 5
#define INT_MAX 0x7fffffff

typedef struct {
    char name[BUFSIZ];
    char dependency[MAX_DEPENDENCY][BUFSIZ];
    char command[MAX_COMMAND][BUFSIZ];
    int dep_num;
    int cmd_num;
} target;

target target_arr[MAX_TARGET];
int target_num = -1;

int run_command(char *);

int main(int argc, char **argv){
    FILE *fp;
    char buf[BUFSIZ];
    char *ptr;

    if((fp = fopen("Makefile", "r")) == NULL){
        fprintf(stderr, "fopen error for Makefile\n");
        exit(1);
    }

    while(fgets(buf, sizeof(buf), fp) != NULL){
        if(buf[0] == '#' || buf[0] == '\n')
            continue;
        if(strchr(buf, ':') != NULL){//target
            target_num++;
            strcpy(target_arr[target_num].name, strtok(buf, ":"));

            if((ptr = strtok(NULL, "\n")) != NULL)
                strcpy(buf, ptr);
            else
                strcpy(buf, "");

            if((ptr = strtok(buf, " ")) != NULL){
                strcpy(target_arr[target_num].dependency[target_arr[target_num].dep_num], ptr);
                target_arr[target_num].dep_num++;
            }

            while((ptr = strtok(NULL, " ")) != NULL){
                strcpy(target_arr[target_num].dependency[target_arr[target_num].dep_num], ptr);
                target_arr[target_num].dep_num++;
            }
        }else{ //command
            strcpy(target_arr[target_num].command[target_arr[target_num].cmd_num], buf);
            target_arr[target_num].cmd_num++;
        }
    }	

    int i;
    if(argc == 1)
        run_command(target_arr[0].name);
    else
        for(i = 1; i < argc; i++)
    run_command(argv[i]);
    exit(0);
}

/**
* target 이름을 입력받아 파일 수정시간은 반환, 파일이 없을 경우 상황에 따라 0 또는 INT_MAX 반환
* 재귀적을 실행되며 의존성 검사와 command를 실행
*/
int run_command(char *target_name){
    struct stat statbuf;
    target cur_target;
    int chk=0;
    int i;

    for(i = 0, chk=1;  i<= target_num; i++){
        if(strcmp(target_name, target_arr[i].name) == 0){
            chk = 0;
            cur_target = target_arr[i];
            break;
        }
    }

    if(chk){//dependency is not in target
        if(access(target_name, F_OK) != 0)
            return INT_MAX;

        stat(target_name, &statbuf);
        return statbuf.st_ctime;
    }

    //target
    if(access(cur_target.name, F_OK) != 0)
        statbuf.st_ctime = 0;
    else
        stat(cur_target.name, &statbuf);

        if(cur_target.dep_num == 0){
            for(i = 0; i < cur_target.cmd_num; i++){
                printf("%s", cur_target.command[i]+1);
                system(cur_target.command[i]);
            }
        return INT_MAX;
    }
    else{
        for(i = 0, chk=0; i < cur_target.dep_num; i++){
            int a;

            if(statbuf.st_ctime < (a=run_command(cur_target.dependency[i])))
                chk = 1;
        }

        if(chk)
            for(i = 0; i < cur_target.cmd_num; i++){
                printf("%s", cur_target.command[i]+1);
                system(cur_target.command[i]);
            }
    }

    //target
    if(access(cur_target.name, F_OK) != 0)
        statbuf.st_ctime = INT_MAX;
    else
        stat(cur_target.name, &statbuf);
    return statbuf.st_ctime;
}