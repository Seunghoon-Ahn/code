#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include<unistd.h>
#define BUF_MAX 4

int main(int argc, char *argv[]) 
{
    int fd;                  // 읽을 파일 디스크립터
    size_t n;                // read()의 리턴값
    int count=0;            // 읽은 파일의 라인수
    char buf[2], cbuf[5];   // read()에서 읽는 버퍼와 출력할 버퍼

    if(argc != 2) {
        fprintf(stderr,"usage : %s file", argv[0]);
        exit(1);
    }
    fd_r = open(argv[1], O_RDONLY);

    if(fd == -1) {
        fprintf(stderr,"open error for %s ",argv[1]);
        exit(1);
    }

    sprintf(cbuf, "%d  ", count);
    if(write(1, cbuf, BUF_MAX) != BUF_MAX) 
        fprintf(stderr,"write error\n");

    while((n = read(fd, buf, 1)) > 0) {
        if(write(1, buf, n) != n)
        fprintf(stderr,"write error\n");
        if(buf[0] == '\n') {
            count++;
            sprintf(cbuf, "%d  ", count);
            if(write(1, cbuf, BUF_MAX) != BUF_MAX)
                fprintf(stderr,"write error");
        }
    }

    if(n == -1)
        fprintf(stderr,"read error");
    close(fd);
}