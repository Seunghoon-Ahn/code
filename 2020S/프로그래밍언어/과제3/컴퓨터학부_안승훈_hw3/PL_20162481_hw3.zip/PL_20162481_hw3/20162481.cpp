﻿#include <iostream>
#include <algorithm>
#include <vector>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <stack>

#define BUF_SIZE 1024

using namespace std;

void print_menu(void);
int menu_select(void);
void menu1(void);
void menu2(void);
void inperpreter(void);
int calcul(char buf[]);
int check(char buf[]);

stack <char> opst;
stack <int> inst;

int main(void)
{
	int choose;
	while (1) {
		choose = menu_select();

		if (choose == 1) {
			menu1();
		}
		else if (choose == 2) {
			menu2();
		}
		else if (choose == 3) {
			inperpreter();
		}
		else if (choose == 4) {
			printf("종료중....\n");
			break;
		}
	}
	return 0;
}

void menu1(void) { //1번 메뉴용 함수
	FILE *fp;
	char input[BUF_SIZE];
	memset(input, 0, sizeof(input));

	if ((fp = fopen("defun.txt", "a+")) == 0) {
		fprintf(stderr, "fopen error for defun.txt\n");
		return;
	}
	fseek(fp, 0, SEEK_END);

	fgets(input, BUF_SIZE, stdin);
	fputs(input + 6, fp);

	fclose(fp);
	return;
}

void menu2(void) {
	FILE *fp;
	char buf[BUF_SIZE];

	if ((fp = fopen("defun.txt", "r+")) == 0) {
		fprintf(stderr, "fopen error for defun.txt\n");
		return;
	}
	printf("\n");
	while (fgets(buf, BUF_SIZE, fp) != NULL) {
		fputs(buf, stdout);
		memset(buf, 0, sizeof(buf));
	}
	printf("\n");

	return;
}

void inperpreter(void) {
	FILE *fp;
	char fname[BUF_SIZE];
	char buf[BUF_SIZE];
	int ck, res = 0;

	printf("실행 파일 명을 입력하세요 >> ");
	fgets(fname, BUF_SIZE, stdin);
	if (fname[strlen(fname) - 1] == '\n')
		fname[strlen(fname) - 1] = '\0';
	if ((fp = fopen(fname, "r")) == 0) {
		fprintf(stderr, "%s file open error!\n", fname);
		return;
	}

	while (fgets(buf, BUF_SIZE, fp) != NULL) {
		printf("*****************************\n");
		if (fname[strlen(buf) - 1] == '\n')
			buf[strlen(buf) - 1] = '\0';
		fputs(buf, stdout);
		ck = check(buf);
		if (ck < 0) {
			printf("\n문장 오류\n");
			continue;
		}
		printf(" -> ");
		//DEFUN에 있는것을 변환하는 함수
		//make_defun();

		printf("\nPrefix to Postfix : ");
		//Postfix 출력
		//make_postfix(); 
		//postfix로 만드는 함수
		//res = calcul(buf);
		printf("\nResult : %d\n", res);
	}

}

int calcul(char buf[]) {
	int cur, x = 0;
	int len = strlen(buf);
	char tmp[10];
	memset(tmp, 0, 10);

	for (cur = 0; cur < len; ) {
		if (buf[cur] == '(') {
			cur++;
			continue;
		}
		else if (buf[cur] == 'M') {
			cur += 5;
			opst.push('M');

		}
		else if (buf[cur] == 'I') {
			cur += 2;
			opst.push('I');
		}
		else if (buf[cur] == '-') {
			x = 0;
			memset(tmp, 0, 10);
			tmp[x++] = buf[cur++];
			while ('0' <= buf[cur] && buf[cur] <= '9')
				tmp[x++] = buf[cur++];

			inst.push(atoi(tmp));
		}
		else if ('0' <= buf[cur] && buf[cur] <= '9') {
			x = 0;
			memset(tmp, 0, 10);
			while ('0' <= buf[cur] && buf[cur] <= '9')
				tmp[x++] = buf[cur++];
			inst.push(atoi(tmp));
		}
		else if (buf[cur] == ' ' || buf[cur] == '\n') {
			cur++;
			continue;
		}
		else if (buf[cur] == ')') {
			char op = opst.top();
			opst.pop();
			int b = inst.top();
			inst.pop();
			int a = inst.top();
			inst.pop();

			if (op == 'M')
				inst.push(a - b);
			else if (op == 'I') {
				if (a <= 0)
					inst.push(0);
				else
					inst.push(b);
			}
			cur++;
		}
	}
	int res = inst.top();
	inst.pop();
	return res;

}

int check(char buf[])
{
	int lcnt = 0, rcnt = 0;
	int len = strlen(buf);
	//괄호 갯수 체크
	for (int i = 0; i < len; i++) {
		if (buf[i] == '(')
			lcnt++;
		else if (buf[i] == ')')
			rcnt++;
	}

	if (lcnt > rcnt) {
		printf("')' 갯수가 부족합니다.\n");
		return -1;
	}
	else if (lcnt < rcnt) {
		printf("'(' 갯수가 부족합니다.\n");
		return -1;
	}

	// -가 여러개 쓰인 경우 체크
	for (int i = 0; i < len; i++) {
		if (buf[i] == '-') {
			if (buf[i + 1] == '-') {
				printf("'-'사용이 잘못되었습니다.\n");
				return -1;
			}
		}
	}
	return 1;
}

int menu_select(void) {
	char input_c = 0;
	int input_i = 0;
	print_menu();
	while (1) {
		scanf("%c", &input_c);
		getchar();
		if (input_c == '1' || input_c == '2' || input_c == '3' || input_c == '4') {
			input_i = input_c - '0';
			return input_i;
		}
		else {
			printf("다시 입력하세요\n");
			printf("메뉴를 선택하세요 >> ");
		}
	}
}

void print_menu(void) {
	printf("=========================\n");
	printf("1. Define DEFUN\n");
	printf("2. Print DEFUN\n");
	printf("3. Interpreter\n");
	printf("4. Exit\n");
	printf("=========================\n");
	printf("메뉴를 선택하세요>> ");
}