#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

#include "sectormap.h"

FILE* flashfp;      
static FILE* tablefp;
static FILE* pagesfp;

int w_cnt, r_cnt, e_cnt;

int main(int argc, char** argv)
{
	// Create flash memory
    flashfp = fopen("flashmemory", "w+");
	if (flashfp == NULL)
	{
		fprintf(stderr, "Failed to create %s\n", "flashmemory");
		exit(EXIT_FAILURE);
	}
	// Fill in flash memory with 0xff
	for (int pbn = 0; pbn < BLOCKS_PER_DEVICE; pbn++)
	{
		char blkbuf[BLOCK_SIZE];
		memset(blkbuf, 0xff, sizeof(blkbuf));
		fwrite(blkbuf, sizeof(blkbuf), 1, flashfp);
	}

	// Create table file to store address-mappig-table
	tablefp = fopen("table", "w+");
	if (flashfp == NULL)
	{
		fprintf(stderr, "Failed to create %s\n", "table");
		exit(EXIT_FAILURE);
	}

	ftl_open();

	int saved_stdout = dup(STDOUT_FILENO);
	///////////////////////////////////////////////////////////////////
	// Simple overwriting test (No garbage collection)
	ftl_write(0, "A0");
	ftl_write(1, "A1");
	ftl_write(2, "A2");
	ftl_write(3, "A3");

	ftl_write(0, "U0");
	ftl_write(1, "U1");
	ftl_write(2, "U2");
	ftl_write(3, "U3");

	dup2(fileno(tablefp), STDOUT_FILENO);
	ftl_print();
	fflush(stdout);
	dup2(saved_stdout, STDOUT_FILENO);

	///////////////////////////////////////////////////////////////////
	fclose(tablefp);
	fclose(flashfp);
	exit(EXIT_SUCCESS);
}
