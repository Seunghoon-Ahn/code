#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

#include "sectormap.h"

FILE* flashfp;      
static FILE* tablefp1;
static FILE* tablefp2;
static FILE* pagesfp;
static FILE* countfp;

int w_cnt = 0, r_cnt = 0, e_cnt = 0;

int main(int argc, char** argv)
{
	// Create flash memory
    flashfp = fopen("flashmemory", "w+");
	if (flashfp == NULL)
	{
		fprintf(stderr, "Failed to create %s\n", "flashmemory");
		exit(EXIT_FAILURE);
	}
	// Fill in flash memory with 0xff
	for (int pbn = 0; pbn < BLOCKS_PER_DEVICE; pbn++)
	{
		char blkbuf[BLOCK_SIZE];
		memset(blkbuf, 0xff, sizeof(blkbuf));
		fwrite(blkbuf, sizeof(blkbuf), 1, flashfp);
	}

	// Create table file to store address-mappig-table
	tablefp1 = fopen("table1", "w+");
	if (flashfp == NULL)
	{
		fprintf(stderr, "Failed to create %s\n", "table1");
		exit(EXIT_FAILURE);
	}

	// Create table file to store address-mappig-table
	tablefp2 = fopen("table2", "w+");
	if (flashfp == NULL)
	{
		fprintf(stderr, "Failed to create %s\n", "table2");
		exit(EXIT_FAILURE);
	}

	// Create pages file to store pages it read
	pagesfp = fopen("pages", "w+a");
	if (flashfp == NULL)
	{
		fprintf(stderr, "Failed to create %s\n", "pages");
		exit(EXIT_FAILURE);
	}

	countfp = fopen("count", "w+");
	if (flashfp == NULL)
	{
		fprintf(stderr, "Failed to create %s\n", "count");
		exit(EXIT_FAILURE);
	}

	ftl_open();

	int saved_stdout = dup(STDOUT_FILENO);
	///////////////////////////////////////////////////////////////////
	// Overwriting test (GC will occur)
	ftl_write(0, "A0");
	ftl_write(1, "A1");
	ftl_write(2, "A#");
	ftl_write(2, "A$");

	ftl_write(4, "B0");
	ftl_write(5, "B1");
	ftl_write(6, "B2");
	ftl_write(7, "B3");

	ftl_write(8,  "C0");
	ftl_write(9,  "C1");
	ftl_write(10, "C2");
	ftl_write(11, "C3");

	ftl_write(12, "D0");
	ftl_write(13, "D1");
	ftl_write(14, "D2");
	ftl_write(15, "D3");

	// Save address-mapping-table before GC occurs
	// to check if free block number was changed
	dup2(fileno(tablefp1), STDOUT_FILENO);
	ftl_print();
	fflush(stdout);
	dup2(saved_stdout, STDOUT_FILENO);

	// Init countet vars before GC occurs
	w_cnt = 0, r_cnt = 0, e_cnt = 0;

	// GC occurs
	ftl_write(2, "U2");

	// Save count vars
	char cntbuf[64] = {0};
	sprintf(cntbuf, "%d %d %d", w_cnt, r_cnt, e_cnt);
	fprintf(countfp, "%s", cntbuf);

	dup2(fileno(tablefp2), STDOUT_FILENO);
	ftl_print();
	fflush(stdout);
	dup2(saved_stdout, STDOUT_FILENO);

	char s0[SECTOR_SIZE];
	char s1[SECTOR_SIZE];
	char s2[SECTOR_SIZE];
	ftl_read(0, s0);
	ftl_read(1, s1);
	ftl_read(2, s2);
	fprintf(pagesfp, "%c%c", s0[0], s0[1]);
	fprintf(pagesfp, "%c%c", s1[0], s1[1]);
	fprintf(pagesfp, "%c%c", s2[0], s2[1]);

	///////////////////////////////////////////////////////////////////
	fclose(tablefp1);
	fclose(tablefp2);
	fclose(flashfp);
	exit(EXIT_SUCCESS);
}
