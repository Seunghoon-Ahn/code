#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

#include "sectormap.h"

FILE* flashfp;
static FILE* tablefp;
static FILE* pagesfp;

int w_cnt, r_cnt, e_cnt;

void dd_read(int, char*);
void dd_write(int, char*);
void dd_erase(int);

int main(int argc, char** argv)
{
	// Create flash memory
    flashfp = fopen("flashmemory", "w+");
	if (flashfp == NULL)
	{
		fprintf(stderr, "Failed to create %s\n", "flashmemory");
		exit(EXIT_FAILURE);
	}
	// Fill in flash memory with 0xff
	for (int pbn = 0; pbn < BLOCKS_PER_DEVICE; pbn++)
	{
		char blkbuf[BLOCK_SIZE];
		memset(blkbuf, 0xff, BLOCK_SIZE);
		fwrite(blkbuf, BLOCK_SIZE, 1, flashfp);
	}

	// Create table file to store address-mappig-table
	tablefp = fopen("table", "w+");
	if (flashfp == NULL)
	{
		fprintf(stderr, "Failed to create %s\n", "table");
		exit(EXIT_FAILURE);
	}

	// Create pages file to store pages it read
	pagesfp = fopen("pages", "w+a");
	if (flashfp == NULL)
	{
		fprintf(stderr, "Failed to create %s\n", "table");
		exit(EXIT_FAILURE);
	}

	ftl_open();

	int saved_stdout = dup(STDOUT_FILENO);
	///////////////////////////////////////////////////////////////////
	// Simple writing test
	ftl_write(0, "A0");
	ftl_write(1, "A1");
	ftl_write(2, "A2");
	ftl_write(3, "A3");

	char s0[SECTOR_SIZE];
	char s1[SECTOR_SIZE];
	char s2[SECTOR_SIZE];
	char s3[SECTOR_SIZE];
	ftl_read(0, s0);
	ftl_read(1, s1);
	ftl_read(2, s2);
	ftl_read(3, s3);
	fprintf(pagesfp, "%c%c", s0[0], s0[1]);
	fprintf(pagesfp, "%c%c", s1[0], s1[1]);
	fprintf(pagesfp, "%c%c", s2[0], s2[1]);
	fprintf(pagesfp, "%c%c", s3[0], s3[1]);

	dup2(fileno(tablefp), STDOUT_FILENO);
	ftl_print();
	fflush(stdout);
	dup2(saved_stdout, STDOUT_FILENO);

	///////////////////////////////////////////////////////////////////
	fclose(tablefp);
	fclose(flashfp);
	exit(EXIT_SUCCESS);
}
